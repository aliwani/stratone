
const projects = [
  {
    id: 0,
    title: "Sana'ani Coffee House",
    year: "2026",
    desc: "The Sana'ani Coffee House identity is built on elegant golden Arabic calligraphy reflecting authenticity, culture, and craftsmanship. Smooth, flowing forms convey warmth and sophistication.",
    desc2:
      "A bold serif wordmark adds balance and modernity, while gold set on black evokes a sense of timeless luxury, uniting heritage with contemporary style.",
    approach:
      "We began by studying Yemeni coffee culture and its calligraphic roots, then shaped a mark where flowing Arabic letterforms carry the brand's soul. Gold and black were chosen deliberately, not just for elegance, but to reflect heritage, warmth, and timeless craftsmanship in every curve.",
    approachPoints: [
      "Calligraphy — flowing Arabic letterforms shaped to carry the brand's cultural soul",
      "Color — gold on black chosen for warmth, luxury, and timelessness",
      "Typography — a bold serif wordmark anchoring tradition with modern balance",
    ],
    Results:
      "A brand identity that feels authentically Yemeni yet timelessly premium — building instant recognition, cultural trust, and a presence that commands attention across every touchpoint.",
    slug: "Sana'ani-Coffee-House",
    category: "Graphic Design",
    client: "Sana'ani-Coffee-House",
    location: "Middle East",

    // ImageKit direct URLs
    HeroSrc:
      "https://ik.imagekit.io/aliwani101/Sanaani-Branding-Hero.jpeg?updatedAt=1785492505818",
    PreviewSrc:
      "https://ik.imagekit.io/aliwani101/Sanaani-Branding-Hero.jpeg?updatedAt=1785492505818",
    TopSrc:
      "https://ik.imagekit.io/aliwani101/Sanaani-Branding-top.jpeg?updatedAt=1785492495469",
    BottomSrc:
      "https://ik.imagekit.io/aliwani101/Sanaani-Branding-bottom.jpeg?updatedAt=1785492504419",
    LeftSrc:
      "https://ik.imagekit.io/aliwani101/Sanaani-Branding-Left.jpeg?updatedAt=1785492491309",
    RightSrc:
      "https://ik.imagekit.io/aliwani101/Sanaani-Branding-Right.jpeg?updatedAt=1785492490671",
  },

  {
    id: 1,
    title: "Shopify store",
    year: "2023-2026",
    desc: "Every Shopify store we build is designed to convert — combining clean aesthetics with purposeful structure. From product layout to checkout flow, each element is shaped to reflect the brand's identity while guiding customers effortlessly toward a decision.",
    desc2:
      "The result is a store that looks premium and performs with precision.",
    approach:
      "We treat every store as a brand experience, not just a product listing — built with clarity and intent.",
    approachPoints: [
      "Design — visually refined layouts that reflect brand identity and build instant trust",
      "Structure — intuitive navigation and product flow that reduces friction and drives action",
      "Optimization — every detail fine-tuned for speed, mobile experience, and conversion",
    ],
    Results:
      "Shopify stores that do more than sell — they build brand credibility, reduce drop-offs, and turn first-time visitors into confident, returning customers through seamless design and purposeful experience.",
    slug: "Shopify-Stores",
    category: "Shopify Store",
    client: "Overall",
    location: "International",

    HeroSrc: "https://ik.imagekit.io/aliwani101/Shopify-Right.webp",
    PreviewSrc: "https://ik.imagekit.io/aliwani101/shopify-Hero.webp",
    TopSrc: "https://ik.imagekit.io/aliwani101/Shopify-Down.webp",
    BottomSrc: "https://ik.imagekit.io/aliwani101/Shopify-Bottom.webp",
    LeftSrc: "https://ik.imagekit.io/aliwani101/Shopify-left.webp",
    RightSrc: "https://ik.imagekit.io/aliwani101/Shopify-Right.webp",
  },

  {
    id: 2,
    title: "Video Editing",
    year: "2024-2026",
    desc: "Each frame is crafted to bring architectural vision to life through cinematic motion, precise pacing, and purposeful storytelling.",
    desc2:
      "From design walkthroughs to explainer edits, every cut is guided by clarity and visual depth, transforming raw footage into a seamless narrative that speaks to both emotion and intellect.",
    approach:
      "We study the design intent before a single edit is made — then build with purpose:",
    approachPoints: [
      "Motion — cinematic flow that amplifies architectural character",
      "Pacing — deliberate cuts that inform and engage",
      "Sound — layered audio that deepens the visual narrative",
    ],
    Results:
      "Cinematic architecture videos that build trust, elevate brand perception, accelerate client decisions, and turn compelling visual storytelling into measurable conversions.",
    slug: "Video-Editing",
    category: "Video Editing",
    client: "OverAll Work",
    location: "International",

    HeroSrc: "/video/Top.mp4",
    PreviewSrc: "/video/editing.jpg",
    TopSrc: "/video/down.mp4",
    BottomSrc: "/video/Bottom.mp4",
    LeftSrc: "/video/Left.mp4",
    RightSrc: "/video/Right.mp4",
  },

  {
    id: 3,
    title: "NexArc Studio",
    year: "2026",
    desc: "Nexarc Studio's social media presence was shaped to reflect the precision and artistry behind their architectural and design work.",
    desc2:
      "Every post, visual, and campaign was crafted to position the studio as a premium design authority — turning scroll-stopping content into meaningful client conversations and lasting brand recognition.",
    approach:
      "We aligned every content decision with Nexarc's design identity — then executed with strategy.",
    approachPoints: [
      "Content — visuals crafted to showcase architectural depth and 3D design excellence",
      "Targeting — reaching clients who value premium, detail-driven design work",
      "Consistency — a cohesive brand voice maintained across every platform and post",
    ],
    Results:
      "A polished digital presence that positions Nexarc Studio as a premium design authority — driving stronger engagement, attracting high-value clients, and building lasting credibility in a competitive market.",
    slug: "NexArc-Studio",
    category: "Social Media Marketing",
    client: "OverAll",
    location: "International",

    // ImageKit direct URLs
    HeroSrc: "https://ik.imagekit.io/aliwani101/compressed-SMM-Prreview.webp",
    PreviewSrc: "https://ik.imagekit.io/aliwani101/compressed-SMM-Prreview.webp",
    TopSrc:
      "https://ik.imagekit.io/aliwani101/SMM-Top.png?updatedAt=1785492490872",
    BottomSrc: "https://ik.imagekit.io/aliwani101/SMM-Bottom.webp",
    LeftSrc: "https://ik.imagekit.io/aliwani101/SMM-Left.webp",
    RightSrc: "https://ik.imagekit.io/aliwani101/SMM-Right.webp",
  },

  {
    id: 4,
    title: "Website Development",
    year: "2025",
    desc: "Every website we develop is built to represent your brand with clarity, credibility, and purpose.",
    desc2:
      "From architecture to interaction, each detail is designed to create a seamless user experience — one that communicates value instantly, holds attention, and transforms visitors into clients with confidence",
    approach:
      "We begin with brand intent and build outward — every decision rooted in purpose and precision.",
    approachPoints: [
      "Design — clean, brand-aligned visuals that establish credibility from the first scroll",
      "Development — fast, responsive, and scalable builds crafted for seamless performance",
      "Experience — intuitive structure and flow that guides every visitor toward meaningful action",
    ],
    Results:
      "Websites that work as hard as your business — building instant trust, reducing bounce rates, and turning purposeful design into a consistent stream of qualified leads and client conversions.",
    slug: "Web-Development",
    category: "Website & App Development",
    client: "OverAll",
    location: "International",

    // ImageKit direct URLs
    HeroSrc: "https://ik.imagekit.io/aliwani101/Web-Hero.webp",
    PreviewSrc: "https://ik.imagekit.io/aliwani101/Web-Hero.webp",
    TopSrc: "https://ik.imagekit.io/aliwani101/Web-Down.webp",
    BottomSrc: "https://ik.imagekit.io/aliwani101/Web-Bottom.webp",
    LeftSrc: "https://ik.imagekit.io/aliwani101/Web-left.webp",
    RightSrc: "https://ik.imagekit.io/aliwani101/Web-Right.webp",
  },
];

export default projects;
